package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.EnquiryDao;
import com.capgemini.contactbook.dao.EnquiryDaoImpl;
import com.capgemini.contactbook.exception.ContactBookxception;
import com.capgemini.contactbook.ui.Client;

public class EnquiryBeanServiceImpl implements EnquiryBeanService{
	EnquiryDao dao=new EnquiryDaoImpl();
	Client c=new Client();
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookxception {
		// TODO Auto-generated method stub
		return dao.addEnquiry(enqry);
	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryId)
			throws ContactBookxception {
		// TODO Auto-generated method stub
		return dao.getEnquiryDetails(EnquiryId);
	}

	
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookxception {
		
		List<String> validationErrors = new ArrayList<String>();
		
	
		if(!(validateName(enqry.getfName()))){
			
			System.err.println("First Name should Start with Capital letter");
			return false;
		}
		if(!(validatelName(enqry.getlName()))){
			System.err.println("Last Name should Start with Capital letter");
			return false;
		}
		if(!(validateMob(enqry.getContactNo()))){
			System.err.println("Mobile number should contain 10 digits");
			return false;
		}
		if(!(validatedomain(enqry.getpDomain()))){
			System.err.println("Domain should Start with Capital letter");
			return false;
		}
		if(!(validatecity(enqry.getpLocation()))){
			System.err.println("Location should Start with Capital letter");
			return false;
		}
		return true;
	}

	@Override
	public int getEmployeeId() throws ContactBookxception {
		// TODO Auto-generated method stub
		return dao.getEmployeeId();
	}

	public boolean validateName(String name) {
		// TODO Auto-generated method stub
		String pattern="[[A-Z][a-z]]{2,}";
		if(Pattern.matches(pattern,name+""))
		{
			return true;
		}else
		return false;
	}
	public boolean validatelName(String lname) {
		// TODO Auto-generated method stub
		String pattern="[a-z]{2,}";
		if(Pattern.matches(pattern,lname+""))
		{
			return true;
		}else
		return false;
	}
	public boolean validateMob(String mob) {
		// TODO Auto-generated method stub
		String pattern="[0-9]{10}";
		if(Pattern.matches(pattern,mob+""))
		{
			return true;
		}else
		return false;
	}
	public boolean validatedomain(String domain) {
		// TODO Auto-generated method stub
		String pattern="[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,domain+""))
		{
			return true;
		}else
		return false;
	}
	public boolean validatecity(String city) {
		// TODO Auto-generated method stub
		String pattern="[A-Z]{1}[a-z]{2,}";
		if(Pattern.matches(pattern,city+""))
		{
			return true;
		}else
		return false;
	}

	
}
