package com.capgemini.contactbook.service;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookxception;

public interface EnquiryBeanService {
	public int addEnquiry(EnquiryBean enqry) throws ContactBookxception;
	public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookxception;
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookxception;
	public int getEmployeeId() throws ContactBookxception;
}
