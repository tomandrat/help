package com.capgemini.contactbook.util;
	import java.io.FileReader;
	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;
	import java.util.Properties;

	import org.apache.log4j.Logger;
	public class DBUtil {
	
		static Logger logger=Logger.getLogger(DBUtil.class);
		private static Connection connection;

		public static Connection getConnection() {
			logger.info("start of getConnection method");
			if (connection == null) {
				try {
					FileReader reader = new FileReader("resources\\jdbc.properties");
				
					Properties properties = new Properties();
					properties.load(reader);
					Class.forName(properties.getProperty("driver"));
					connection = DriverManager.getConnection(
							properties.getProperty("url"),
							properties.getProperty("userName"),
							properties.getProperty("password"));
					//System.out.println("hii");
				} catch (IOException e) {
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					logger.error("Problem Occurred while loading the driver class"+e.getMessage());
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}
			logger.info("End of getConnection method");
			return connection;
		}
		
	}


