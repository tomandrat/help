package com.capgemini.contactbook.dao;

public interface QueryMapper {
	public static final String insert="Insert into global_enquiry values(?,?,?,?,?,?)";
	public static final String search="select * from global_enquiry where enqryid=?";
}
