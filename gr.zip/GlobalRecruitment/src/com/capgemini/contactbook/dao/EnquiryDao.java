package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.exception.ContactBookxception;

public interface EnquiryDao {
public int addEnquiry(EnquiryBean enqry) throws ContactBookxception;
public EnquiryBean getEnquiryDetails(int EnquiryId) throws ContactBookxception;
public int generateEnqryId() throws ContactBookxception;
public int getEmployeeId() throws ContactBookxception;

}
