package com.cap.stu.dto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cap.stu.bean.Student;
import com.cap.stu.util.DBUtil;

public class StudentDaoImpl implements StudentDao {
Connection con;
	@Override
	public int addEmployee(Student obj) {
		// TODO Auto-generated method stub
		 int stuId=generatestid();
			con = DBUtil.getConnection();
			try {
				PreparedStatement preparedstatement = con
						.prepareStatement(QueryMapper.INSERT);
				preparedstatement.setInt(1,stuId);
				preparedstatement.setString(2,obj.getStName());
				preparedstatement.setInt(3,obj.getStfee());
				preparedstatement.setDate(4,Date.valueOf(obj.getBdate()));
				preparedstatement.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return stuId;
	}

	@Override
	public ArrayList<Student> getAllEmployee() {
		// TODO Auto-generated method stub
		ArrayList<Student> stlist=new ArrayList<Student>();
		con=DBUtil.getConnection();
		Statement statement;
		try {
			statement = con.createStatement();
			ResultSet resultset=statement.executeQuery(QueryMapper.SEARCH);
			while(resultset.next()){
				Student st=new Student();
				st.setStId(resultset.getInt(1));
				st.setStName(resultset.getString(2));
				st.setStfee(resultset.getInt(2));
				stlist.add(st);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stlist;
	}

	@Override
	public Student getEmployeeById(int stId) {
		// TODO Auto-generated method stub
		Student student=new Student();
		// TODO Auto-generated method stub
		con=DBUtil.getConnection();
		try {
			PreparedStatement preparedstatement = con
					.prepareStatement(QueryMapper.SELECT);
			preparedstatement.setLong(1,stId);
		ResultSet resultset=preparedstatement.executeQuery();
		while(resultset.next()){
			student.setStId(resultset.getInt("stid"));
			student.setStName(resultset.getString("stname"));
			student.setStfee(resultset.getInt("stfee"));
			student.setBdate(resultset.("bdate"));
			
		}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int removeDetails(int stId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateId(int stId, int stfee) {
		// TODO Auto-generated method stub
		return 0;
	}
	public int generatestid() {
		int stId = 0;
		String SQL = "select st_seq.nextval from dual";
		con = DBUtil.getConnection();
		try {
			Statement statement = con.createStatement();
			ResultSet resultset = statement.executeQuery(SQL);
			resultset.next();
			stId = resultset.getInt(1);
		} catch (SQLException e) {
			System.out.println("Problem while generating stId\n"+e.getMessage());
		}
		return stId;
	}

	

}
