package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftDAO {
	public long addDemandDraftDetails(DemandDraft demandDraft);
	DemandDraft getDemandDraftDetails(int transactionId);
	

}
/*public interface IDemandDraftService {
	int addDemandDraftDetails(DemandDraft demandDraft);
	DemandDraft getDemandDraftDetails(int transactionId);
	public boolean validateDemandDraft(DemandDraft demandDraft);

}
*/