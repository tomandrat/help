package com.capgemini.bank.dao;

public interface QueryMapper {
	public static final String INSERTQUERY="insert into demand_draft values(?,?,?,?,sysdate,?,?,?)";
	public static final String DISPLAY="select * from demand_draft where transaction_id=?";
	
}
