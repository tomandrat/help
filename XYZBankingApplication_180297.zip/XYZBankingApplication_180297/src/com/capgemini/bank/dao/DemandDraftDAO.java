package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.DBUtil;




public class DemandDraftDAO implements IDemandDraftDAO{
		Connection con;

public DemandDraftDAO() {
		// TODO Auto-generated constructor stub
	}
	public long generateTransactionId() {
		int transactionId=1001;
		String SQL = "select transaction_id_seq.nextval from dual";
		con = DBUtil.getConnection();
		try {
			Statement statement = con.createStatement();
			ResultSet resultset = statement.executeQuery(SQL);
			resultset.next();
			transactionId = resultset.getInt(1);
		} catch (SQLException e) {
			System.out.println("Problem while generating ProductId\n"+e.getMessage());
		}
		return transactionId;
	}
	public int getcommission(){
		int commission=0,amount=0;
		return 0;
	}
	@Override
	public long addDemandDraftDetails(DemandDraft demandDraft) {
		//System.out.println(demandDraft);
		//System.out.println("hsgszg");
		long transactionId=generateTransactionId();
		//System.out.println(transactionId);
		//System.out.println();
//		System.out.println(Date.valueOf(demandDraft.getDateOfTransaction()));
		con = DBUtil.getConnection();
//		System.out.println(con);
		try {
			//System.out.println("gfsgs");
			PreparedStatement preparedstatement = con.prepareStatement(QueryMapper.INSERTQUERY);
			//System.out.println("helooo");
			//System.out.println(demandDraft.getCustomer_Name());
			preparedstatement.setLong(1,transactionId);
			preparedstatement.setString(2, demandDraft.getCustomer_Name());
			preparedstatement.setString(3,demandDraft.getInFavorOf());
			preparedstatement.setLong(4, demandDraft.getPhone_Number());
			//preparedstatement.setString(5,demandDraft.getDateOfTransaction());
			preparedstatement.setLong(5,demandDraft.getDd_Amount());
			preparedstatement.setLong(6,demandDraft.getDd_commission());
			preparedstatement.setString(7,demandDraft.getDd_Description());
			preparedstatement.executeUpdate();
			//System.out.println(demandDraft.getCustomer_Name()+"");
			/*preparedstatement = con.prepareStatement(QueryMapper.Customer_QUERY_SEQUENCE);
			Statement statement=con.createStatement();
			ResultSet  resultset = preparedstatement.executeQuery();
			resultset.next();
			System.out.println("you Productid is "+resultset.getString(1));*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return transactionId;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		/*List<DemandDraft> productlist=new ArrayList<DemandDraft>();
		con=DBUtil.getConnection();
		Statement statement;
		try {
			statement = con.createStatement();
			ResultSet resultset=statement.executeQuery(QueryMapper.DISPLAY);
			while(resultset.next()){
				DemandDraft draft=new DemandDraft();
				draft.setDd_Amount(resultset.getLong(1));
				draft.(resultset.getString(3));
				draft.setDd_Description(resultset.getString(2));
				productlist.add(draft);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			return null;
		}*/
		/*String sql = "Select * from purchasedetails where purchaseid=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, purchaseid);
		ResultSet set = ps.executeQuery();
		//System.out.println(purchaseid);
		PurchaseDetails pd = null;
		while (set.next()) {
			pd= new PurchaseDetails();
			pd.setPurchaseid(set.getInt(1));
			pd.setCname(set.getString(2));
			pd.setMailid(set.getString(3));
			pd.setPhoneno(set.getString(4));
			pd.setPurchasedate(set.getDate(5).toLocalDate());
			pd.setMobileid(set.getInt(6));
			//purchaseDetails.executeUpdate();
		}
		return pd;
	}*/
		DemandDraft dd=new DemandDraft();
		// TODO Auto-generated method stub
		con=DBUtil.getConnection();
		try {
			PreparedStatement preparedstatement = con
					.prepareStatement(QueryMapper.DISPLAY);
			preparedstatement.setInt(1,transactionId);
		ResultSet resultset=preparedstatement.executeQuery();
		while(resultset.next()){
			dd.setTransaction_Id(resultset.getInt(1));
			dd.setCustomer_Name(resultset.getString(2));
			dd.setInFavorOf(resultset.getString(3));
			dd.setPhone_Number(resultset.getLong(4));
			dd.setDateOfTransaction(resultset.getString(5));
			dd.setDd_Amount(resultset.getLong(6));
			dd.setDd_commission(resultset.getLong(7));
			dd.setDd_Description(resultset.getString(8));
			
		}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dd;
	}
}

