package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;


public class DemandDraftService implements IDemandDraftService{
	IDemandDraftDAO dao=new DemandDraftDAO();

	public DemandDraftService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public long addDemandDraftDetails(DemandDraft demandDraft) {
		//System.out.println("hoooooooooo");
		dao.addDemandDraftDetails(demandDraft);
		return demandDraft.getTransaction_Id();
		//return dao.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		dao.getDemandDraftDetails(transactionId);
		// TODO Auto-generated method stub
		return dao.getDemandDraftDetails(transactionId);
	}
	public boolean validateDemandDraft(DemandDraft demandDraft) {

		
		return true;
	}

}
