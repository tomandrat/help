package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {
	public long addDemandDraftDetails(DemandDraft demandDraft);
	DemandDraft getDemandDraftDetails(int transactionId);
	public boolean validateDemandDraft(DemandDraft demandDraft);

}
