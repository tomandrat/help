package com.capgemini.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exception.DraftDBException;

public class test {
static DemandDraftDAO dao;
static DemandDraft draft;

@BeforeClass
public static void initialize(){
	System.out.println("in before class");
	dao=new DemandDraftDAO();
	draft=new DemandDraft();
}
@Test
public void testAdddraftDetails() throws DraftDBException{
	assertNotNull(dao.addDemandDraftDetails(draft));
}
@Ignore
@Test
public void testAdddraftDetails1() throws DraftDBException{
	assertEquals(10115,dao.addDemandDraftDetails(draft));
}
@Test
public void testAdddraftDetails2() throws DraftDBException{
	draft.setCustomer_Name("zv");
	draft.setInFavorOf("guzsgv");
	draft.setPhone_Number(3544);
	draft.setDateOfTransaction("04-jun-2019");
	draft.setDd_Amount(20000);
	draft.setDd_commission(51);
	draft.setDd_Description("sfa");
	assertTrue("data inserted");
}
private void assertTrue(String string) {
	// TODO Auto-generated method stub
	
}
@Test
public void testByid() throws DraftDBException {
	assertNotNull(dao.getDemandDraftDetails(10114));
}
@Ignore
@Test
public void testByid1() throws DraftDBException {
	assertEquals("edg",dao.getDemandDraftDetails(10013).getCustomer_Name());
}
}
