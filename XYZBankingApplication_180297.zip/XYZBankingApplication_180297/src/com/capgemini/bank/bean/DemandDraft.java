package com.capgemini.bank.bean;

import java.time.LocalDate;

public class DemandDraft {
	private long transaction_Id;
	private String customer_Name;
	private String inFavorOf;
	private long phone_Number;
	String dateOfTransaction;
	private long dd_Amount;
	private long dd_commission;
	private String dd_Description;
	/**
	 * @author sumith
	 * @param remarks 
	 * @param j 
	 * @param amount 
	 * @param string 
	 * @param cphone 
	 * @param favor 
	 * @param cname 
	 * @param i 
	 */
public DemandDraft() {
	// TODO Auto-generated constructor stub
}

	public DemandDraft(long transaction_Id, String customer_Name,
			String inFavorOf, long phone_Number, String dateOfTransaction,
			long dd_Amount, long dd_commission, String dd_Description) {
		super();
		this.transaction_Id = transaction_Id;
		this.customer_Name = customer_Name;
		this.inFavorOf = inFavorOf;
		this.phone_Number = phone_Number;
		this.dateOfTransaction = dateOfTransaction;
		this.dd_Amount = dd_Amount;
		this.dd_commission = dd_commission;
		this.dd_Description = dd_Description;
	}

	public long getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(long transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public long getPhone_Number() {
		return phone_Number;
	}
	public void setPhone_Number(long phone_Number) {
		this.phone_Number = phone_Number;
	}
	public String getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(String dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public long getDd_Amount() {
		return dd_Amount;
	}
	public void setDd_Amount(long dd_Amount) {
		this.dd_Amount = dd_Amount;
	}
	public long getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(long dd_commission) {
		this.dd_commission = dd_commission;
	}
	public String getDd_Description() {
		return dd_Description;
	}
	public void setDd_Description(String dd_Description) {
		this.dd_Description = dd_Description;
	}
	@Override
	public String toString() {
		return "DemandDraft [transaction_Id=" + transaction_Id
				+ ", customer_Name=" + customer_Name + ", inFavorOf="
				+ inFavorOf + ", phone_Number=" + phone_Number
				+ ", dateOfTransaction=" + dateOfTransaction + ", dd_Amount="
				+ dd_Amount + ", dd_commission=" + dd_commission
				+ ", dd_Description=" + dd_Description + "]";
	}

}
