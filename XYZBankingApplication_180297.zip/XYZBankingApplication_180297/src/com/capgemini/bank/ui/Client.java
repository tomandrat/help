package com.capgemini.bank.ui;

import java.io.ObjectInputStream.GetField;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DraftDBException;
import com.capgemini.bank.exception.InvalidDraftException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;




public class Client {
	static String date;
		public static void main(String[] args) {
			
			Scanner scanner=new Scanner(System.in);
		IDemandDraftService service=new DemandDraftService();
			do{
				System.out.println("----------------------------------------");
				System.out.println("||---------------Menu-----------------||");
				System.out.println("||1. Enter Demand Draft Details:      ||");
				System.out.println("||2. Print Demand Draft:              ||");
				System.out.println("||3. Exit                             ||");
				System.out.println("----------------------------------------");
				System.out.println("Enter your choice");
				int choice=scanner.nextInt();
			switch(choice){
			case 1:
				long n=0,cm;
				long commission=0;
				System.out.println("Enter the Name of the Customer:");
				String cname=scanner.next();
				System.out.println("Enter customer phone number:");
				long cphone=scanner.nextLong();
				System.out.println("In favor of:");
				String favor=scanner.next();
				System.out.println("Enter Demand Draft amount (in Rs):");
				long amount=scanner.nextLong();
				if(amount<5000) 
				{
					commission=10;
			        }
				else if(amount>5000 && amount<10000)
				{
				commission=41;
				}
				else if(amount>10000 && amount<100000){
					commission=51;
			}
				if(amount>100001&&amount<500000){
					commission=306;
				}
			System.out.println(commission);

				System.out.println("Enter Remarks:");
				String remarks=scanner.next();
				LocalDate format=null;
				
				DemandDraft p=new DemandDraft(n,cname,favor,cphone,date,amount,commission,remarks);
				
				try{
					if(service.validateDemandDraft(p)){
						//System.out.println("hii");
						service.addDemandDraftDetails(p);
						System.out.println("Your Demand Draft request has been successfully registered along with");}
					}catch(Exception e){
						System.out.println(e.getMessage());
					}
					break;
			case 2:
				System.out.println("Plz Enter transaction id:");
				int transaction_id=scanner.nextInt();
				DemandDraft dd=service.getDemandDraftDetails(transaction_id);
				System.out.println("---------XYZ Bank--------------");
				System.out.println("Customer name="+dd.getCustomer_Name());
				System.out.println("Phone Number:"+dd.getPhone_Number());
				System.out.println("Amount:"+dd.getDd_Amount());
				System.out.println("commission:"+dd.getDd_commission());
				long acco=dd.getDd_Amount();
				long cc=dd.getDd_commission();
				long ta=acco+cc;
				System.out.println("Total Amount:"+ta);
				
				
				break;
				
				
			case 3:System.exit(0);
			
		}
		}while(true);
		}
}