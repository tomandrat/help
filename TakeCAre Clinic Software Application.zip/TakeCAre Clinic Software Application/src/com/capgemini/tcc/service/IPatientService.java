package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TccException;

public interface IPatientService {

	int addPatientDetails(PatientBean pb) throws TccException;

	PatientBean getPatientDetails(int pid) throws TccException;

}
