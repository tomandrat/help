package com.cg.mra.dao;

public interface QueryMapper {
	public static final String SEARCH=" Select acc_balance from accounts where account_id=?";
	public static final String Rech=" Select account_id,account_type,Customer_name,acc_balance from accounts where account_id=?";
public static final String up="update accounts set acc_balance=? where account_id=?";
}