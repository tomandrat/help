package com.cg.mra.dao;

import com.cg.mra.beans.Account;

public interface AccountDao {
Account getAccountDetails(String accountId);
int rechargeAccount(String accountId,int rechargeAmount);
}
