package com.cg.mra.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.mra.beans.Account;
import com.cg.mra.util.DBUtil;


public class AccountDaoImpl implements AccountDao {
Connection con;
	@Override
	public Account getAccountDetails(String accountId) {
		Account acc=new Account();
		// TODO Auto-generated method stub
		con=DBUtil.getConnection();
		try {
			PreparedStatement preparedstatement = con
					.prepareStatement(QueryMapper.SEARCH);
			preparedstatement.setString(1,accountId);
			//System.out.println(accountId);
		ResultSet resultset=preparedstatement.executeQuery();
		while(resultset.next()){
			
			//resultset.getDouble(1);
			acc.setAccounBalance(resultset.getDouble(1));
			//product.setProductPrice(resultset.getDouble("productprice"));*/
			
		
		}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return acc;
	}

	@Override
	public int rechargeAccount(String accountId, int rechargeAmount) {
	int accounBalance=0;
		Account ac=new Account();
		con=DBUtil.getConnection();
		try {
			PreparedStatement preparedstatement = con
					.prepareStatement(QueryMapper.Rech);
			preparedstatement.setString(1,accountId);
			//preparedstatement.setInt(2,rechargeAmount);
		
		ResultSet resultset=preparedstatement.executeQuery();
		while(resultset.next())
		{
			//resultset.getDouble(1);
			ac.setAccountId(accountId);
			ac.setAccountType(resultset.getString(2));
			ac.setCustomerName(resultset.getString(3));
			ac.setAccounBalance(resultset.getDouble(4));
			 accounBalance=resultset.getInt(4);
			
			//product.setProductPrice(resultset.getDouble("productprice"));
		}
		
		// System.out.println(accounBalance);
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(ac==null)
		{
			System.out.println("Cant recharge account as given id doesnt exist");
			
		}
		double newAccBal=accounBalance+rechargeAmount;
		//System.out.println(88);
		
		try{
			
			PreparedStatement statement = con
					.prepareStatement(QueryMapper.up);
			//PreparedStatement statement=con.prepareStatement();
			//System.out.println(getAccountDetails(accountId));
			statement.setDouble(1,newAccBal);
			statement.setString(2,accountId);
			statement.executeUpdate();
		}catch(SQLException e){
			//Logger.error(e.getMessage());
		}
		return 0;
		
	}

}
