package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {
	Account getAccountDetails(String accountId);
	int rechargeAccount(String accountId,int rechargeAmount);
	public boolean validateProduct(Account account) ;
	public boolean validateAmount(String rechargeAmount) ;
}
