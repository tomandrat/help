package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService{
AccountDao account=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String accountId) {
		// TODO Auto-generated method stub
		account.getAccountDetails(accountId);
		return account.getAccountDetails(accountId);
	}

	@Override
	public int rechargeAccount(String accountId, int rechargeAmount) {
		// TODO Auto-generated method stub
		//account.rechargeAccount(accountId, rechargeAmount);
		return account.rechargeAccount(accountId, rechargeAmount);
	}

	@Override
	public boolean validateProduct(Account account) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validateAmount(String rechargeAmount) {
		// TODO Auto-generated method stub
		return true;
	}
}