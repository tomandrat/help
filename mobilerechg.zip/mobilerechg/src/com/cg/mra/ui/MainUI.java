package com.cg.mra.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
	AccountService service=new AccountServiceImpl();
	do{
		System.out.println("Menu\n1. Account Balance Enquiry");
		System.out.println("2. Recharge Account");
		System.out.println("3. Exit");
		System.out.println("Enter your choice");
		int choice=scanner.nextInt();
		switch(choice){
		case 1:
			System.out.println("Enter AccountId:");
			String accId=scanner.next();
			
			
			try{
				Account p=service.getAccountDetails(accId);
if(service.validateProduct(p)){
					
					System.out.println("AccounBalance:"+p.getAccounBalance());
					//System.out.println("");}
				}}//catch(InvalidProductException e){
					//System.out.println(e.getMessage());
				catch(Exception e){
					System.out.println(e.getMessage());
				}
				break;
		case 2:
			System.out.println("Enter AccountId:");
			String acId=scanner.next();
			System.out.println("Enter Recharge Amount");
			int rech=scanner.nextInt();
			//Account id=service.rechargeAccount(accountId, rechargeAmount);
			try{
			/*if(service.validateAmount(acId)){
				
				
				//System.out.println("");}
			}*/
			service.rechargeAccount(acId,rech);
			System.out.println("your recharge was successful");}//catch(InvalidProductException e){
				//System.out.println(e.getMessage());
			catch(Exception e){
				System.out.println(e.getMessage());
			}
			break;
			
		case 3: System.exit(0);
		
		default:System.out.println("Invalid choice try Again");
		}
		}while(true);
	}
	}



