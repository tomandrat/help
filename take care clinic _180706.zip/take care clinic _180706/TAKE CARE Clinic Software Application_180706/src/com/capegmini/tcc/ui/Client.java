package com.capegmini.tcc.ui;

import java.sql.Date;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TccException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		IPatientService pser=new PatientService();
		
	
		do {
			System.out.println("WELCOME TO TAKE CARE CLINIC");
			System.out.println("1.Add Patient Information");
			System.out.println("2.Search Patient by Id:");
			System.out.println("3.Exit");
			System.out.println("enter your choice:");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter patient name:");
				String patient_Name = sc.next();
				System.out.println("enter your age:");
				int age = sc.nextInt();
				System.out.println("enter phone no:");
				String phone = sc.next();
				System.out.println("enter description:");
				String description = sc.next();
				PatientBean pb = new PatientBean(patient_Name, age, phone,
						description);
				try {
					int id=	pser.addPatientDetails(pb);
					System.out.println("Patient details entered successfull with id: "+id);
				} catch (TccException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("enter patient Id to get patientDetails:");
				int pid=sc.nextInt();
				try {
					PatientBean p= pser.getPatientDetails(pid);
					System.out.println(p);
				} catch (TccException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 3:
				System.exit(0);
				break;

			}
		} while (true);
	
	
	}

}
