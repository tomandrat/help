package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDao;
import com.capgemini.tcc.dao.PatientDao;
import com.capgemini.tcc.exception.TccException;

public class PatientService implements IPatientService {

	IPatientDao dao=new PatientDao();
	@Override
	public int addPatientDetails(PatientBean pb) throws TccException {
		// TODO Auto-generated method stub
		return dao.addPatientDetails(pb);
	}
	@Override
	public PatientBean getPatientDetails(int pid) throws TccException {
		// TODO Auto-generated method stub
		return dao.getPatientDetails(pid);
	}

}
