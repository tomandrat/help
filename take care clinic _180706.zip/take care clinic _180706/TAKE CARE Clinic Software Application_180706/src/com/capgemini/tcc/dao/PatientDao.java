package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dbutil.DBUtil;
import com.capgemini.tcc.exception.TccException;

public class PatientDao implements IPatientDao{
	Connection conn = null;
	
	Logger logger=Logger.getRootLogger();
	
	 public PatientDao() {
		 PropertyConfigurator.configure("Resource/log4j.properties");
	}
	
	@Override
	public int addPatientDetails(PatientBean pb) throws TccException {
		conn = DBUtil.getConnection();
		if(conn!=null)
		logger.info("connection successfull");
		pb.setPatient_Id(generatePatientId());
		String sql="INSERT INTO Patient VALUES(?,?,?,?,?,sysdate)";
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,pb.getPatient_Id());
			pst.setString(2,pb.getPatient_Name());
			pst.setInt(3,pb.getAge());
			pst.setString(4,pb.getPhone());
			pst.setString(5,pb.getDescription());
			ResultSet rst=pst.executeQuery();
			logger.info("Details inserted successfull");
		} catch (SQLException e) {
			throw new TccException("sql error");
		}
		
		return pb.getPatient_Id();
	}

	public int generatePatientId() throws TccException {
		int pid = 0;
			conn = DBUtil.getConnection();
			try {
				Statement stmt = conn.createStatement();
				ResultSet rst = stmt.executeQuery("SELECT patient_id_seq.NEXTVAL FROM dual");
				rst.next();
				pid = rst.getInt(1);
			} catch (SQLException e) {
				throw new TccException("Problem in generating  id "+ e.getMessage());
			}
			logger.info("sequence generated successfully");
			return pid;
	
	}

	@Override
	public PatientBean getPatientDetails(int pid) throws TccException {
		
		PatientBean pb;
		String sql="Select * from Patient where patient_id=?";
		conn = DBUtil.getConnection();
	
		try {
			pb=new PatientBean();
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,pid);
			ResultSet rst = pst.executeQuery();
	while(rst.next())
	{
		pb.setPatient_Id(rst.getInt(1));
		pb.setPatient_Name(rst.getString(2));
		pb.setAge(rst.getInt(3));
		pb.setPhone(rst.getString(4));
		pb.setDescription(rst.getString(5));
		pb.setConsultation_Date(rst.getDate(6));
		
	}
			
		} catch (SQLException e) {
			throw new TccException("sql error");
		}
		
		logger.info("Succeeded in fetching data from database ");
		
		return pb;
	}
	
	
	
	
	
	
	
	

}
