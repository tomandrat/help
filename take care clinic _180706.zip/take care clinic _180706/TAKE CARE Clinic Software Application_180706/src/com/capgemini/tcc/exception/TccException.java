package com.capgemini.tcc.exception;

public class TccException extends Exception {

	public TccException() {
		// TODO Auto-generated constructor stub
	}

	public TccException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TccException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public TccException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public TccException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
