package com.cap.flat.bean;

public class FlatOwner {
	private int owner_Id;
	private String owner_Name;
	private String mobile;
	

	public FlatOwner() {
		// TODO Auto-generated constructor stub
	}


	public FlatOwner(int owner_Id, String owner_Name, String mobile) {
		super();
		this.owner_Id = owner_Id;
		this.owner_Name = owner_Name;
		this.mobile = mobile;
	}


	public int getOwner_Id() {
		return owner_Id;
	}


	public void setOwner_Id(int owner_Id) {
		this.owner_Id = owner_Id;
	}


	public String getOwner_Name() {
		return owner_Name;
	}


	public void setOwner_Name(String owner_Name) {
		this.owner_Name = owner_Name;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	@Override
	public String toString() {
		return "FlatOwner [owner_Id=" + owner_Id + "]";
	}
	

/*
	@Override
	public String toString() {
		return "FlatOwner [owner_Id=" + owner_Id + ", owner_Name=" + owner_Name
				+ ", mobile=" + mobile + "]";
	}
	*/

}
