package com.cap.flat.bean;

public class FlatRegistration {
	private long flatRegNo;
	private long ownerId;
	private long flattype;
	private long flatArea;
	private long rentAmount;
	private long depositAmount;

	public FlatRegistration() {
		// TODO Auto-generated constructor stub
	}

	public FlatRegistration(long flatRegNo, long ownerId, long flattype,
			long flatArea, long rentAmount, long depositAmount) {
		super();
		this.flatRegNo = flatRegNo;
		this.ownerId = ownerId;
		this.flattype = flattype;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}

	public long getFlatRegNo() {
		return flatRegNo;
	}

	public void setFlatRegNo(long flatRegNo) {
		this.flatRegNo = flatRegNo;
	}

	public long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(long ownerId) {
		this.ownerId = ownerId;
	}

	public long getFlattype() {
		return flattype;
	}

	public void setFlattype(long flattype) {
		this.flattype = flattype;
	}

	public long getFlatArea() {
		return flatArea;
	}

	public void setFlatArea(long flatArea) {
		this.flatArea = flatArea;
	}

	public long getRentAmount() {
		return rentAmount;
	}

	public void setRentAmount(long rentAmount) {
		this.rentAmount = rentAmount;
	}

	public long getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(long depositAmount) {
		this.depositAmount = depositAmount;
	}

	@Override
	public String toString() {
		return "FlatRegistration [flatRegNo=" + flatRegNo + ", ownerId="
				+ ownerId + ", flattype=" + flattype + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depositAmount="
				+ depositAmount + "]";
	}
}

	