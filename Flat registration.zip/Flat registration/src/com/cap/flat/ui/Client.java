package com.cap.flat.ui;

import java.util.Scanner;

import com.cap.flat.bean.FlatRegistration;
import com.cap.flat.service.FlatregistrationService;
import com.cap.flat.service.IFlatRegistrationService;

public class Client {
	public static void main(String[] args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		IFlatRegistrationService pser = new FlatregistrationService();
		do {
			System.out.println("*********Menu*********");
			System.out.println("1. RegisterFlat");
			System.out.println("2. Exit");
			System.out.println("Enter your choice");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				
				System.out.println("Existion Owner Ids are"
						+ pser.getAllOwnerId());
				pser.generateFlatRegNo();
				System.out.println("Enter Owner Id:");
				long oid = scanner.nextLong();
				System.out.println("Enter FlatType[1-BHK,2-BHK]:");
				long ft = scanner.nextLong();
				System.out.println("Enter FlatArea:");
				long fa = scanner.nextLong();
				System.out.println("Enter RentAmount:");
				long ra = scanner.nextLong();
				System.out.println("Enter DepositAmount:");
				long da = scanner.nextLong();
				FlatRegistration fr=new FlatRegistration(0,oid,ft,fa,ra,da); 
				if(ra>da){
				if(pser.validateProduct(fr)){
				pser.registerFlat(fr);
				}
				System.out.println("flat registered SuccessFully"+pser.generateFlatRegNo());
				}else
					{
				throw new Exception("Deposit amount should be less than rent amount");
					}	break;
			}
		} while (true);
	}
}