package com.cap.flat.dao;

import java.util.List;

import com.cap.flat.bean.FlatOwner;
import com.cap.flat.bean.FlatRegistration;

public interface IFlatRegistrationDao {
FlatRegistration registerFlat(FlatRegistration flat);
List<Integer> getAllOwnerId();
public long generateFlatRegNo();
}
