package com.cap.flat.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cap.flat.bean.FlatOwner;
import com.cap.flat.bean.FlatRegistration;
import com.cap.flat.util.DBUtil;

public class FlatRegistrationDao implements IFlatRegistrationDao{
Connection con;
	@Override
	public FlatRegistration registerFlat(FlatRegistration flat) {
		// TODO Auto-generated method stub
		long flatregno=generateFlatRegNo();
		con = DBUtil.getConnection();
		try {
			PreparedStatement preparedstatement = con
					.prepareStatement(Querymapper.Insert);
			preparedstatement.setLong(1,flatregno);
			preparedstatement.setLong(2,flat.getOwnerId());
			preparedstatement.setLong(3,flat.getFlattype());
			preparedstatement.setLong(4,flat.getFlatArea());
			preparedstatement.setLong(5,flat.getRentAmount());
			preparedstatement.setLong(6,flat.getDepositAmount());
			preparedstatement.executeUpdate();
			/*preparedstatement = con.prepareStatement(QueryMapper.Customer_QUERY_SEQUENCE);
			Statement statement=con.createStatement();
			ResultSet  resultset = preparedstatement.executeQuery();
			resultset.next();
			System.out.println("you Productid is "+resultset.getString(1));*/
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flat;
	}
	

	@Override
	public List<Integer> getAllOwnerId() {
		// TODO Auto-generated method stub
		List<Integer> productlist=new ArrayList<Integer>();
		con=DBUtil.getConnection();
		Statement statement;
		try {
			statement = con.createStatement();
			ResultSet resultset=statement.executeQuery(Querymapper.Retrieve);
			while(resultset.next()){
				FlatOwner flat=new FlatOwner();
				flat.setOwner_Id(resultset.getInt(1));
				/*flat.setOwner_Name(resultset.getString(2));
				flat.setMobile(resultset.getString(2));*/
				productlist.add(flat.getOwner_Id());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			return productlist;
		
	}
	public long generateFlatRegNo() {
	long FlatRegNo=0;
		String SQL = "select flat_seq.nextval from dual";
		con = DBUtil.getConnection();
		try {
			Statement statement = con.createStatement();
			ResultSet resultset = statement.executeQuery(SQL);
			resultset.next();
			FlatRegNo = resultset.getLong(1);
			//System.out.println(FlatRegNo);
		} catch (SQLException e) {
			System.out.println("Problem while generating ProductId\n"+e.getMessage());
		}
		return FlatRegNo;
	}

}

