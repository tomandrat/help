package com.cap.flat.dao;

public interface Querymapper {
	public static final String Retrieve="select owner_id from Flat_owners";
	public static final String Insert="Insert into flat_registration values(?,?,?,?,?,?)";
}
