package com.cap.flat.service;

import java.util.List;

import com.cap.flat.bean.FlatOwner;
import com.cap.flat.bean.FlatRegistration;
import com.cap.flat.dao.FlatRegistrationDao;
import com.cap.flat.dao.IFlatRegistrationDao;

public class FlatregistrationService implements IFlatRegistrationService {
IFlatRegistrationDao ser=new FlatRegistrationDao();
	@Override
	public FlatRegistration registerFlat(FlatRegistration flat) {
		// TODO Auto-generated method stub
		return ser.registerFlat(flat);
	}

	@Override
	public List<Integer> getAllOwnerId() {
		// TODO Auto-generated method stub
		return ser.getAllOwnerId();
	}

	@Override
	public long generateFlatRegNo() {
		// TODO Auto-generated method stub
		return ser.generateFlatRegNo();
	}

	@Override
	public boolean validateProduct(FlatRegistration flat) throws Exception {
		// TODO Auto-generated method stub
		boolean d=false;
		List<Integer> flat1=ser.getAllOwnerId();
		for(Integer i:flat1)
		{
			if((flat.getOwnerId())==i){
				d=true;
				break;
			}
		}
		if(d==false){
			throw new Exception("invalid id");
		}
		return true;
	}



}
