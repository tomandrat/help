package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.TccException;

public interface IPatientDao {

	int addPatientDetails(PatientBean pb) throws TccException;

	PatientBean getPatientDetails(int pid) throws TccException;

}
